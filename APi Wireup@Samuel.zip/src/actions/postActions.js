import {FETCH_POSTS,ERROR} from './types';
import axios from 'axios';

export const fetchPosts = () => async dispatch => {
    try{
      const res = await axios.get(`https://jsonplaholder.typicode.com/posts`)
        dispatch( {
            type: FETCH_POSTS,
            payload: res.data,
        })
    }
    catch(error) {
        console.log(error); 
        dispatch( {
            type: ERROR,
            payload: error,
        })
    }
  }
 
 



